import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Polyline } from "react-leaflet";
import "leaflet/dist/leaflet.css";

function App() {
  const [cities, setCities] = useState([]);
  const [from, setFrom] = useState("Bangkok");
  const [to, setTo] = useState("Chiang Mai");
  const [mode, setMode] = useState("train");
  const [route, setRoute] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5000/api/cities")
      .then(res => res.json())
      .then(data => setCities(data));
  }, []);

  const fetchRoute = () => {
    fetch(`http://localhost:5000/api/routes?from=${from}&to=${to}&mode=${mode}`)
      .then(res => res.json())
      .then(data => setRoute(data));
  };

  return (
    <div style={{ height: "100vh", width: "100vw" }}>
      <div style={{ position: "absolute", top: 10, left: 10, zIndex: 1000, background: "white", padding: "10px", borderRadius: "8px" }}>
        <div>
          <label>From: </label>
          <select value={from} onChange={e => setFrom(e.target.value)}>
            {cities.map(city => (
              <option key={city} value={city}>{city}</option>
            ))}
          </select>
        </div>
        <div>
          <label>To: </label>
          <select value={to} onChange={e => setTo(e.target.value)}>
            {cities.map(city => (
              <option key={city} value={city}>{city}</option>
            ))}
          </select>
        </div>
        <div>
          <label>Mode: </label>
          <select value={mode} onChange={e => setMode(e.target.value)}>
            <option value="train">Train</option>
            <option value="bus">Bus</option>
            <option value="plane">Plane</option>
            <option value="ferry">Ferry</option>
          </select>
        </div>
        <button onClick={fetchRoute} style={{ marginTop: "10px" }}>Show Route</button>
      </div>

      <MapContainer center={[15.87, 100.99]} zoom={6} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {route && (
          <Polyline
            positions={route.geometry.coordinates.map(([lng, lat]) => [lat, lng])}
            pathOptions={{ color: "blue" }}
          />
        )}
      </MapContainer>
    </div>
  );
}

export default App;
