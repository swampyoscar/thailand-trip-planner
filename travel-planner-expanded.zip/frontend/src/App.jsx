import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Polyline } from "react-leaflet";
import "leaflet/dist/leaflet.css";

function App() {
  const [route, setRoute] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5000/api/routes?from=Bangkok&to=Chiang%20Mai&mode=train")
      .then(res => res.json())
      .then(data => setRoute(data));
  }, []);

  return (
    <div style={{ height: "100vh", width: "100vw" }}>
      <MapContainer center={[15.87, 100.99]} zoom={6} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {route && (
          <Polyline
            positions={route.geometry.coordinates.map(([lng, lat]) => [lat, lng])}
            pathOptions={{ color: "blue" }}
          />
        )}
      </MapContainer>
    </div>
  );
}

export default App;
