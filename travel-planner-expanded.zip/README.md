# Travel Planner

## Setup

### Backend
```bash
cd backend
npm install
npm start
```
Backend runs at http://localhost:5000

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend runs at http://localhost:5173

---
This is a starter travel planner app with Bangkok → Chiang Mai route.
