import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

const COSTS = { train: 500, bus: 400, plane: 2000, ferry: 300 };

const CITIES = {
  Bangkok: [100.5018, 13.7563],
  "Chiang Mai": [98.9853, 18.7883]
};

app.get("/api/routes", async (req, res) => {
  const { from, to, mode } = req.query;
  if (!CITIES[from] || !CITIES[to]) {
    return res.status(400).json({ error: "Unknown city" });
  }

  const [fromLng, fromLat] = CITIES[from];
  const [toLng, toLat] = CITIES[to];

  const response = await fetch(
    `https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson`
  );
  const data = await response.json();

  res.json({
    from,
    to,
    mode,
    distance: data.routes[0].distance / 1000,
    duration: data.routes[0].duration / 3600,
    cost: COSTS[mode] || 100,
    geometry: data.routes[0].geometry
  });
});

app.listen(PORT, () => console.log(`API running on port ${PORT}`));
